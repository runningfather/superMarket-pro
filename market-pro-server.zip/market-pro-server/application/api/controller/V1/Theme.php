<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:49
 */

namespace app\api\controller\V1;


use app\api\validate\IDCollection;
use app\api\model\Theme as ThemeModel;
use app\api\validate\IDMustBePostiveInt;
use app\lib\exception\BannerMissException;

use think\exception\TemplateNotFoundException;
use think\Request;

class Theme
{
    public function getSimpleList(){
        (new IDCollection())->goCheck();
        $ids = Request::instance()->param('ids');

        $idArr = explode(',',$ids);

        foreach ($idArr as $id){
            if($id)
            {
                echo $id;
            }
        }


        $result = ThemeModel::with('TopicImage,HeadImage')
                  ->select($idArr);
        if(!$result){
            throw new ThemeMissException();
        }
        return json($result);
    }



    public function getComplexOne($id){
        ((new IDMustBePostiveInt())->goCheck());
        $result = ThemeModel::getThemeWithProducts($id);

        if(!$result){
            throw new TemplateNotFoundException();
        }

        return json($result);
    }
}

