<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:28
 */

namespace app\api\model;


class Theme extends BaseModel
{
   public function TopicImage(){
       /*
        * $this -> hasOne() 如果在image中要用hasOne； 查询模块实在belongsTo
        * */
       return $this -> belongsTo('Image','topic_img_id','id');
   }

   public function HeadImage(){
       return $this -> belongsTo('Image','head_img_id','id');
   }

   public function products(){
       /*
        * belongsToMany()多对多的关系
        * */
       return $this -> belongsToMany('product','theme_product',
           'product_id','theme_id');
   }


   public static function getThemeWithProducts($id){
       $theme = self::with('products,TopicImage,headImage')
                ->find($id);
       return $theme;
   }
}

