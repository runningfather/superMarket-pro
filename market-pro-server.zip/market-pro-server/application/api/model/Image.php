<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 15:20
 */

namespace app\api\model;


use think\Model;

class Image extends BaseModel
{
    protected $hidden=['delete_time','update_time'];

    public function getUrlAttr($value,$data){
        /*
         * 有getUrlAttr方法，有url会自动继承
         * 继承的另一种方法
         * */
        return $this -> prefixImgUrl($value,$data);
    }
}