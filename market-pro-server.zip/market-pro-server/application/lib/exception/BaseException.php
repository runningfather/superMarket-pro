<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/26
 * Time: 15:22
 */

namespace app\lib\exception;


use think\Exception;
use Throwable;

class BaseException extends Exception
{
        /*
         * 初始化
         * 判断是否是数组形式
         * 判断数组是否有该key，true后赋值
         *
         * */
        public $code = 400 ;
        public $msg = '参数错误';
        public $errorCode = 10000;


        public function __construct($params=[])
        {
           if(!is_array($params)){
               return;
           }

           if(array_key_exists('code',$params)){
               $this->code=$params['code'];
           }

            if(array_key_exists('msg',$params)){
                $this->msg=$params['msg'];
            }

            if(array_key_exists('errorCode',$params)){
                $this->errorCode=$params['errorCode'];
            }
        }
}
