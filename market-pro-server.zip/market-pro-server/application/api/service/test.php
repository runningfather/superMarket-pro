<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/15
 * Time: 8:53
 */

namespace app\api\service;


class test extends BaseController
{
    protected $c =[];
    protected function X()
    {
        //protected 只能写在function外面。里面需要变量可以直接写，需要外部变量或父类变量可以$this->c dian出来
         $A = [['a' => "b"]];
        foreach ($A as $item) {
            array_push($this->c,$item['a']);
        }
        echo $this->c;
    }
}