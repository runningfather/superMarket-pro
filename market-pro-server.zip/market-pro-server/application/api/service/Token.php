<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/6/3
 * Time: 18:42
 */

namespace app\api\service;


class Token
{
        public static function generateToken(){
            /*
             * 生成token 放在common里
             * 用三组字符串，进行md5加密
             * */
            $randChars = getRandChar(32);
            $timestamp = $_SERVER['REQUEST_TIME_FLOAT'];//时间戳
            $salt = config('secure.token_salt');
            return md5($randChars.$timestamp.$salt);

        }
}