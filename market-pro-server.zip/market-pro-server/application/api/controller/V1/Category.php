<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/29
 * Time: 16:26
 */

namespace app\api\controller\V1;

use app\api\model\Category as categoryModel;
use app\lib\exception\CategoryException;

class Category
{
    public function getAllCategories(){

        /*
         * 新写法all 可涵盖with
         * */
        $result = categoryModel::all([],'image');
        if(!$result){
            throw new CategoryException();
        }
        return json($result);
    }
}
