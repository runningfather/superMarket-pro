<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/6/3
 * Time: 22:37
 */

namespace app\lib\exception;


class weChatException extends BaseException
{
    public $code = 400;
    public $msg = '微信服务器接口调用失败';
    public $errorCode = 999;
}