<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/29
 * Time: 15:54
 */

namespace app\api\validate;


class Count extends BaseValidate
{
    protected $rule=[
        /*
         * 不要在验证规则中加空格
         * */
        'count'=> 'isPositiveInteger|between:1,15'
    ];
}