<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/11/16
 * Time: 9:42
 */

namespace app\api\controller;


class Test
{
  public function hello(){
      return'hello';
  }
}