<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/5/27
 * Time: 14:33
 */

namespace app\api\service;


use app\api\model\OrderProduct;
use app\api\model\Product;
use app\api\model\UserAddress;
use app\api\model\Order as OrderModel;
use app\api\validate\OrderPlace;
use app\lib\enum\OrderStatusEnum;
use app\lib\exception\OrderException;
use app\lib\exception\UserException;
use think\Db;
use think\Exception;

class Order
{
    // 订单的商品列表，也就是客户端传递过来的products参数
    protected $oProducts;

    // 真实的商品信息（包括库存量）
    protected $products;

    protected $uid;

    //下单行为  知道给谁下单 下单内容
    public function place($uid, $oProducts)
    {
        //oProducts和products 作对比
        // products从数据库中查询出来
        $this->oProducts = $oProducts;
        $this->products = $this->getProductsByOrder($oProducts); //235根据订单信息查找真实的商品信息 getProductsByOrder（）在下方）235
        $this->uid = $uid;
        $status = $this->getOrderStatus();    //160 返回订单详情页、搞定订单状态
        if (!$status['pass'])                 //查看订单状态是否通过
        {
            $status['order_id'] = -1;        //订单创建失败了
            return $status;
        }

        //开始创建订单   快照->order表
        $orderSnap = $this->snapOrder($status); //107 生成订单快照
        $order = $this->createOrder($orderSnap); //   将快照写入数据库
        $order['pass'] = true;                   //告诉客户端通过了
        return $order;
    }

    private function createOrder($snap)  //创建订单
    {
        Db::startTrans();   //开始 完整的事物，避免断电等情况导致数据记录不完整
        try   //对数据库的操作最好要写try catch
        {
            $orderNo = $this->makeOrderNo();  //生成订单号
            $order = new \app\api\model\Order();  //order模型
            $order->user_id = $this->uid;     //录入快照信息，填充上订单的信息
            $order->order_no = $orderNo;
            $order->total_price = $snap['orderPrice'];
            $order->total_count = $snap['totalCount'];
            $order->snap_img = $snap['snapImg'];
            $order->snap_name = $snap['snapName'];
            $order->snap_address = $snap['snapAddress'];
            $order->snap_items = json_encode($snap['pStatus']);

            $order->save();  //保存
//           1/0  中途中断造成事物不一致的情况断电
            $orderID = $order->id;                      //order表中的id给OrderID
            $create_time = $order->create_time;         //将order表中的creat_time给creat_time 一开始是没有值

            foreach ($this->oProducts as &$p)           //拿到订单数组下的每一个子项
            {
                $p['order_id'] = $orderID;              //将order表中的id赋值给order_pruduct表中的order_id
            }
            $orderProduct = new OrderProduct();         //模型实例化
            $orderProduct->saveAll($this->oProducts);   //保存一组数据
            Db::commit(); //完整事物记录结束
            return [
                'order_no' => $orderNo,             //返回订单号
                'order_id' => $orderID,             //订单ID
                'create_time' => $create_time       //订单创建的时间
            ];
        }
        catch (Exception $ex)
        {
            Db::rollback(); //发生错误 回滚一下撤销（事物的应用）
            throw $ex;
        }
    }
        //生成订单号
    public static function makeOrderNo()//生成订单号  防止订单号重复
    {
        $yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
        $orderSn =     //date('Y')获取当前时间减2018 得到0 为A   月把dechex转化十六进制通过stroupper转化成大写字符串 日substr时间戳形式
            $yCode[intval(date('Y')) - 2018] . strtoupper(dechex(date('m'))) . date(
                'd') . substr(time(), -5) . substr(microtime(), 2, 5) . sprintf(
                '%02d', rand(0, 99));
        return $orderSn;
    }

    // 生成订单快照
    private function snapOrder($status) //49
    {
        $snap = [                       //订单快照
            'orderPrice' => 0,          //订单价格
            'totalCount' => 0,          //订单数量
            'pStatus' => [],            //状态
            'snapAddress' => null,      //收货地址
            'snapName' => '',           //商品名字
            'snapImg' => ''             //商品图片
        ];

        $snap['orderPrice'] = $status['orderPrice'];        //直接读取
        $snap['totalCount'] = $status['totalCount'];        //所有商品总数量
        $snap['pStatus'] = $status['pStatusArray'];         //
        $snap['snapAddress'] = json_encode($this->getUserAddress()); //到数据库get地址。将数组转化为字符串记录  133                   其实最好使用非关系型数据库
        $snap['snapName'] = $this->products[0]['name'];             //>1修正
        $snap['snapImg'] = $this->products[0]['main_img_url'];

        if (count($this->products) > 1)   //数量大于1 加个等字
        {
            $snap['snapName'] .= '等';
        }

        return $snap;
    }
    //获取订单快照->用户地址
    private function getUserAddress()
    {
        $userAddress = UserAddress::where('user_id', '=', $this->uid) //Useraddress模型
            ->find();
        if (!$userAddress)
        {
            throw new UserException(  //没有找到
                [
                    'msg' => '用户收货地址不存在，下单失败',
                    'errorCode' => 60001,
                ]);
        }
        return $userAddress->toArray();  //查到是一个对象不是一个数组数据调用toArray（）方法返回回去，对象无法return
    }
     //提供一个对外微信支付pay的方法 接收一个orderID进行订单的查询
    public function checkOrderStock($orderID)
    {
        $oProducts = OrderProduct::where('order_id','=',$orderID)
            ->select();
        $this->oProducts = $oProducts;  //通过orderID到order_products模型中查询订单信息

        $this->products = $this->getProductsByOrder($oProducts); //160 获取products的方法  拆分方法
        $status = $this->getOrderStatus();  //再调用getOrderStatus（）获取订单数据状态的验证
        return $status;
    }

    //返回订单的状态-查询订单检测是否通过‘’接收两个数组但是已经写入成员变量 获取订单的真实状态，查询订单检测是否通过
    private function getOrderStatus()   //154
    {
        $status = [   //记录了所有最详细订单的一个信息 所有操作都是为了这家伙
            'pass' => true,
            'orderPrice' => 0,
            'totalCount' => 0,   //每种商品数量总和
            'pStatusArray' => []//该数组，用来保存订单所有商品的详细信息  之前的数组只保存了订单商品id
        ];

        foreach ($this->oProducts as $oProduct) //遍历取出订单的某一个元素，用来查询其详细信息然后push进详情数组
        {
            $pStatus = $this->getProductStatus(  //检测库存量是否大于订单量186 传进去三属性
                $oProduct['product_id'], $oProduct['count'], $this->products
            );
            if (!$pStatus['haveStock']) //haveStock就是这一个判断该订单是否通过 如果是false所有订单都不通过
            {
                $status['pass'] = false; //订单状态不通过
            }
            $status['orderPrice'] += $pStatus['totalPrice']; //订单所有总价格的累加
            $status['totalCount'] += $pStatus['counts'];      //总数量的累加

            array_push($status['pStatusArray'], $pStatus); //然后将记录好的订单详情放进详情数组$status['pStatusArray']。订单详情页搞定
        }
        return $status; //返回总订单详情
    }
    //检测库存量是否大于订单量 将订单被遍历的id传进来 订单数量 将已知products传进来-->找到数量进行比较
    private function getProductStatus($oPID, $oCount, $products) //171 第二层
    {
        $pIndex = -1;     //确定序号+初始化 准备拉入循环

        $pStatus = [         //初始化订单属性 保存每个订单内某种商品的信息
            'id' => null,
            'haveStock' => false,
            'counts' => 0, //保存当前订单所请求的数量
            'price' => 0,
            'name' => '',
            'totalPrice' => 0, //某一商品的总价格 数量*单价
            'main_img_url' => null
        ];

        for ($i = 0; $i < count($products); $i++)  //这里的count是php中用来统计数量的方法
        {
            if ($oPID == $products[$i]['id']) //如果这个$opid是等于该数组下面的的i号元素他的id属性的话 成立说明该i号元素就是我们要找的商品
            {
                $pIndex = $i;  //上面定义的确定序列号的PIndex
            }
        }

        if ($pIndex == -1)  //如果PIndex不存在说明是该订单的记录错误 抛出OrderException
        {
            // 客户端传递的product_id有可能根本不存在
            throw new OrderException(
                [
                    'msg' => 'id为' . $oPID . '的商品不存在，创建订单失败'  //提示
                ]);
        }
        else
        {    //为赋值做准备    这个东西最主要目的是为了记录订单做的
            $product = $products[$pIndex];   //拿到对应的pIndex了，填写PState数组 用来做订单详情的数据
            $pStatus['id'] = $product['id'];  // 以下均为对其赋值
            $pStatus['name'] = $product['name'];
            $pStatus['counts'] = $oCount;
            $pStatus['price'] = $product['price'];
            $pStatus['main_img_url'] = $product['main_img_url'];
            $pStatus['totalPrice'] = $product['price'] * $oCount;

            if ($product['stock'] - $oCount >= 0) //这是用查询到的数量减去订单数量 没问题状态为true
            {
                $pStatus['haveStock'] = true;  //它的初始化时false所以小于0是不会变的大于0变true
            }
        }

        return $pStatus; //$pStatus这家伙填充完毕可以返回了 订单页要使用
    }

    // 根据订单信息查找真实的商品信息
    private function getProductsByOrder($oProducts)
    {
        //        foreach ($oProducts as $oProduct){
        //            //循环的查询数据库
        //        }
        $oPIDs = [];      //数组 将订单商品id放入 然后通过数组到数据库做易查询
        foreach ($oProducts as $item)
        {
            array_push($oPIDs, $item['product_id']);   //这是循环写入数组的方法***
        }
        $products = Product::all($oPIDs)              //易查询
            ->visible(['id', 'price', 'stock', 'name', 'main_img_url']) //与hidden相反显示方法
            ->toArray();   //->toArray（）转换成一个数组
        return $products;
    }

    public function delivery($orderID, $jumpPage = '')
    {
        $order = OrderModel::where('id', '=', $orderID)
            ->find();
        if (!$order) {
            throw new OrderException();
        }
        if ($order->status != OrderStatusEnum::PAID) {
            throw new OrderException([
                'msg' => '还没付款呢，想干嘛？或者你已经更新过订单了，不要再刷了',
                'errorCode' => 80002,
                'code' => 403
            ]);
        }
        $order->status = OrderStatusEnum::DELIVERED;
        $order->save();
        //            ->update(['status' => OrderStatusEnum::DELIVERED]);
        $message = new DeliveryMessage();
        return $message->sendDeliveryMessage($order, $jumpPage);
    }
}