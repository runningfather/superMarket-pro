<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/29
 * Time: 20:34
 */

namespace app\api\controller\V1;

use app\api\service\UserToken ;
use app\api\validate\TokenGet ;

class Token
{

    /*
     * 验证code是否合格
     * 实例化service模块，调用生成token方法
     * 返回客户端token
     * */
    public function getToken($code=''){
        ((new TokenGet())->goCheck());
        $ut = new UserToken($code);
        $token =$ut ->get($code);
        return $token;
    }
}