<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 15:16
 */

namespace app\api\model;


use think\Model;

class BannerItem extends Model
{
    /*
     * 嵌套关联关系
     * */
    protected $hidden=['delete_time','update_time'];

    public function Images(){
       return $this ->belongsTo('image','img_id','id');
    }
}