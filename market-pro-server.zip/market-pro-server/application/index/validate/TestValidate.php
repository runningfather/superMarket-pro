<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/13
 * Time: 13:50
 */

namespace app\index\validate;


use think\Validate;

class TestValidate extends BaseValidate
{
    protected  $rule=[
        'name'=>'require|max:5',
        'email'=>'email'
    ];
}