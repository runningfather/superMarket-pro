<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/13
 * Time: 12:32
 */

namespace app\index\model;


use think\Exception;
use think\Model;
use think\Db;

class Banner extends Model
{
    public function item(){
        return $this->hasMany('BannerItem','banner_id','id');
    }
    public static function getBannerByID($id)
{



}
}

