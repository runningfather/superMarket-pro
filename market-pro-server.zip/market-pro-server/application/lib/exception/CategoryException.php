<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/29
 * Time: 16:37
 */

namespace app\lib\exception;


class CategoryException extends BaseException
{
    public $code = 404;
    public $message = '查找无该分类商品,请检查参数';
    public $errorCode = 50000;
}