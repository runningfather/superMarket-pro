<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:27
 */

namespace app\api\model;


class Order extends BaseModel
{

}