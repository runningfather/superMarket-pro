<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/6/5
 * Time: 10:06
 */

namespace app\api\service;

use app\api\model\Order as OrderModel;
use app\api\model\Product;
use app\api\service\Order as OrderService;
use app\lib\enum\OrderStatusEnum;
use think\Db;
use think\Exception;
use think\Loader;
use think\Log;

Loader::import('WxPay.WxPay', EXTEND_PATH, '.Api.php');

class WxNotify extends \WxPayNotify
{
    //<xml>
    //<appid><![CDATA[wx2421b1c4370ec43b]]></appid>
    //<attach><![CDATA[支付测试]]></attach>
    //<bank_type><![CDATA[CFT]]></bank_type>
    //<fee_type><![CDATA[CNY]]></fee_type>
    //<is_subscribe><![CDATA[Y]]></is_subscribe>
    //<mch_id><![CDATA[10000100]]></mch_id>
    //<nonce_str><![CDATA[5d2b6c2a8db53831f7eda20af46e531c]]></nonce_str>
    //<openid><![CDATA[oUpF8uMEb4qRXf22hE3X68TekukE]]></openid>
    //<out_trade_no><![CDATA[1409811653]]></out_trade_no>
    //<result_code><![CDATA[SUCCESS]]></result_code>
    //<return_code><![CDATA[SUCCESS]]></return_code>
    //<sign><![CDATA[B552ED6B279343CB493C5DD0D78AB241]]></sign>
    //<sub_mch_id><![CDATA[10000100]]></sub_mch_id>
    //<time_end><![CDATA[20140903131540]]></time_end>
    //<total_fee>1</total_fee>
    //<trade_type><![CDATA[JSAPI]]></trade_type>
    //<transaction_id><![CDATA[1004400740201409030005092168]]></transaction_id>
    //</xml>

    public function NotifyProcess($data, &$msg)
    {
        if ($data['result_code'] == 'SUCCESS') //将上面xml接收的微信数据库发送的参数.作为判断一下步是否成功
        {
            $orderNo = $data['out_trade_no'];  //订单号
            Db::startTrans(); //完整事件
            try
            {
                $order = OrderModel::where('order_no', '=', $orderNo) //查询订单信息
                    ->lock(true)  //对查询语句加锁
                    ->find();
                if ($order->status == 1) //只处理订单未支付的情况 1为未支付
                {
                    $service = new OrderService();
                    $stockStatus = $service->checkOrderStock($order->id);  //从订单模型拿出订单号进行库存量检测查询
                    if ($stockStatus['pass'])
                    {
                        $this->updateOrderStatus($order->id, true); //通过 更新订单数据表订单状态 未支付->支付成功
                        $this->reduceStock($stockStatus);  //通过验证减库存
                    }
                    else
                    {
                        $this->updateOrderStatus($order->id, false);  //已支付但是库存不足
                    }
                }
                Db::commit();
                return true;  //返回给微信小弟成功了e
            }
            catch (Exception $ex)
            {
                Db::rollback();
                Log::error($ex);
                return false;  //出现异常事件回滚
            }
        }
        else
        {
            return true;  //最后还是要谭塞一下微信小弟，否则你会被烦死~
        }
    }

    private function reduceStock($stockStatus)   //购买成功减少库存
    {
        foreach ($stockStatus['pStatusArray'] as $singlePStatus)
        {
            //            $singlePStatus['count']
            Product::where('id', '=', $singlePStatus['id'])   //对某一字段做减法setDec
                ->setDec('stock', $singlePStatus['counts']);
        }
    }

    private function updateOrderStatus($orderID, $success)  // 知道订单号 接收一个标志位true/false
    {
        $status = $success ?
            OrderStatusEnum::PAID :    //验证库存状态
            OrderStatusEnum::PAID_BUT_OUT_OF;  //未通过
        OrderModel::where('id', '=', $orderID)  //更新数据库该条order的状态
            ->update(['status' => $status]);
    }

}