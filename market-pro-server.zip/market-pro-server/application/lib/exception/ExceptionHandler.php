<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/26
 * Time: 15:22
 */

namespace app\lib\exception;


use think\Exception;
use think\exception\Handle;
use think\Request;
use think\Log;

class ExceptionHandler extends Handle
{
    private $code;
    private $msg;
    private $errorCode;
    //需要返回客户端当前请求路径

    public function render(\Exception $e)
    {
        if ($e instanceof BaseException)
        {
            //如果是自定义的异常
            $this->code = $e->code;
            $this->msg = $e->msg;
            $this->errorCode = $e->errorCode;
        }

        /*
         * 用户操作异常
         * 数据库异常
         * 数据库错误日记记录
         * 要从Request实例对象拿到返回的url
         * 需要返回客户端当前请求路径
         * */


        else {
            /*
             * 开关
             * config函数用于文件中快速的读取文件信息
             * */

            if(config('app_debug')){
                    return Parent::render($e);
            }else{
                $this->code = 500;
                $this->msg = '服务器错误，不想告诉你';
                $this->errorCode = 999;
                $this->recordErrorLog($e);


            }
        }

        $request = Request::instance();

        $result=[
        'msg'=> $this->msg,
        'request_url'=> $request->url(),
        'errorCode'=> $this->errorCode
    ];
        return json($result,$this->code);
    }

    /*
     * 日记异常记录
     * 日志配置初始化(File 路径 错误级别)
     * */
    private function recordErrorLog(\Exception $e){
        Log::init([
           'type'=>'File',
           'path'=>LOG_PATH,
           'level' => ['error']
        ]);
        Log::record($e->getMessage(),'error');
    }
}



