<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/5/31
 * Time: 14:18
 */

namespace app\api\model;


class OrderProduct extends BaseModel
{
    
}