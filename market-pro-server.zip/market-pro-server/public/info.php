<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/10
 * Time: 15:24
 */
phpinfo();