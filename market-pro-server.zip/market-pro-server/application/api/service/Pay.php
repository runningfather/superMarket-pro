<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/6/1
 * Time: 17:08
 */

namespace app\api\service;


use app\api\model\Order as OrderModel;
use app\api\service\Order as OrderService;
use app\lib\enum\OrderStatusEnum;
use app\lib\exception\OrderException;
use app\lib\exception\TokenException;
use think\Exception;
use think\Loader;
use think\Log;

//   extend/WxPay/WxPay.Api.php 微信支付
Loader::import('WxPay.WxPay', EXTEND_PATH, '.Api.php');                               //Loader需要use   1can:子文件夹与文件开头  2路径 3.Api.php 所需要合成完整路径

class Pay
{
    private $orderID;  //订单id
    private $orderNO;   //订单号

    function __construct($orderID)   //传入orderID
    {
        if (!$orderID)  //验证orderID 订单号不允许为空
        {
            throw new Exception('订单号不允许为NULL');
        }
        $this->orderID = $orderID;  //给成员变量赋值
    }

    public function pay()  //处理支付的主方法
    {
        //订单号可能根本就不存在
        //订单号确实是存在的，但是，订单号和当前用户是不匹配的
        //订单有可能已经被支付过
        //进行库存量检测
        $this->checkOrderValid(); //检测订单是否存在，是否有恶意提交，以及支付状态 115
        $orderService = new OrderService(); //new一个订单模型
        $status = $orderService->checkOrderStock($this->orderID);
        if (!$status['pass'])  //查看库存量检测是否通过
        {
            return $status;
        }
        return $this->makeWxPreOrder($status['orderPrice']);  //微信订单生成
    }

    private function makeWxPreOrder($totalPrice)  //微信预订单生成
    {
        //openid
        $openid = Token::getCurrentTokenVar('openid');//在缓存中获取OpenID的值
        if (!$openid)
        {
            throw new TokenException();
        }                   //没有命名空间的话要加入一个反斜杠
        $wxOrderData = new \WxPayUnifiedOrder(); //定义一个变量接收实例化统一下单输入对象 将参数赋值给这个对象在调用一些方法获得我们需要的数据
        $wxOrderData->SetOut_trade_no($this->orderNO);  //1.订单号放到对象中
        $wxOrderData->SetTrade_type('JSAPI');       //2.固定交易类型JSAPI
        $wxOrderData->SetTotal_fee($totalPrice * 100);  //3.设置支付的总金额，以分作为单位
        $wxOrderData->SetBody('零食商贩');                 //4.商品描述
        $wxOrderData->SetOpenid($openid);                       //商户身份标识
        $wxOrderData->SetNotify_url(config('secure.pay_back_url'));     //告诉微信访问这个接口
        return $this->getPaySignature($wxOrderData);  //发送给微信预订单
    }

    private function getPaySignature($wxOrderData) //1.微信对预订单响应生成响应结果2.并将需要的参数返回客户端以提供支付请求
    {                                                  //最后由小程序向微信发送支付请求
        $wxOrder = \WxPayApi::unifiedOrder($wxOrderData);  //调用微信的接口 接收封装的参数，返回一个具体的结果成功或者失败
        if ($wxOrder['return_code'] != 'SUCCESS' ||
            $wxOrder['result_code'] != 'SUCCESS'           //结果是这样代表调用失败了
        )
        {
            Log::record($wxOrder, 'error');  //记录日志 调用Log的record记录日志 不抛异常
            Log::record('获取预支付订单失败', 'error');
        }
        //prepay_id  向用户主动推送模板消息
        $this->recordPreOrder($wxOrder);       //存储prepayID
        $signature = $this->sign($wxOrder);         //生成参数数组参数数组）
        return $signature;                            //返回数组给客户端（参数数组）
    }

    private function sign($wxOrder)
    {
        $jsApiPayData = new \WxPayJsApiPay();   //实例化微信sdk提供的类 ，用这个类实现返回客户端的参数
        $jsApiPayData->SetAppid(config('wx.app_id')); //从配置文件读取AppID
        $jsApiPayData->SetTimeStamp((string)time());    //给他一个时间戳

        $rand = md5(time() . mt_rand(0, 1000));   //生成随机字符串的方法
        $jsApiPayData->SetNonceStr($rand);        //传递一个随机字符串的参数

        $jsApiPayData->SetPackage('prepay_id='.$wxOrder['prepay_id']);  //把prepay_id给它
        $jsApiPayData->SetSignType('md5');                              //signType md5

        $sign = $jsApiPayData->MakeSign();                                     //调用该类制作签名
        $rawValues = $jsApiPayData->GetValues();                                //获取数组包含以上的所有参数返回客户端去
        $rawValues['paySign'] = $sign;                                          //添加签名

        unset($rawValues['appId']);                                             //把appId从该数组中删除

        return $rawValues;                                                       //将数组返回客户端
    }

    private function recordPreOrder($wxOrder)  //处理prepayId order表中有一个prepayId字段
    {
        OrderModel::where('id', '=', $this->orderID)    //筛选条件
            ->update(['prepay_id' => $wxOrder['prepay_id']]);   //更新字段
    }                 //要更新的字段    更新字段的取值

    private function checkOrderValid()  //检测订单是否存在，是否有恶意提交，以及支付状态
    {
        $order = OrderModel::where('id', '=', $this->orderID)
            ->find();  //通过模型查询该订单号
        if (!$order)  //如果该查询结果不存在要抛出异常
        {
            throw new OrderException();
        }
        if (!Token::isValidOperate($order->user_id)) //把id拉进去检测没有通过抛出异常
        {
            throw new TokenException(
                [
                    'msg' => '订单与用户不匹配',//（调用了他人订单）
                    'errorCode' => 10003
                ]);
        }
        if ($order->status != OrderStatusEnum::UNPAID)  //判断订单支付/未支付状态 枚举1:未支付， 2：已支付，3：已发货 , 4: 已支付，但库存不足
        {
            throw new OrderException(
                [
                    'msg' => '订单已支付过啦',
                    'errorCode' => 80003,
                    'code' => 400
                ]);
        }
        $this->orderNO = $order->order_no;  //将订单编号给成员变量
        return true;
    }
}