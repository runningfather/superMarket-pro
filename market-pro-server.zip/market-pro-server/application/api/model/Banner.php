<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/26
 * Time: 14:38
 */

namespace app\api\model;


use think\Db;
use think\Exception;
use think\Model;

class Banner extends Model
{

    /*
     *
     * 类名与表名对应  Banner类 对应 Banner表
     * 可自定义
     * 主要业务表连接
     * protected $table = 'category';
     * */

    public static function getBannerByIDT($id){

        /*
         * 因$ex已从Exception拿到错误类型
         * */
        try{
            1/0;
        }
        catch (Exception $ex)
        {
            throw $ex;
        }

        return 'this is banner info';
    }

    public static function getBannerByIDTM($id){

           $result= Db::query('select * from banner_item where banner_id=?',[$id]);

           return $result;
    }

    public static function getBannerByIDTM1($id){

        $result= Db::table('banner_item')
        ->where(function ($query)use ($id){
            $query->where('banner_id','=',$id);
        })
        ->select();
        return $result;
    }


    public static function getBannerByIDTMVISABLE($id){

        $banner = self::with(['items','items.images'])
            ->find($id)
            ->visible(['update_time','delete_time']);

        return $banner;

    }
    /*
     * 实现两个作用
     * 1.实现模板简单操作 隐藏/显示 多表关联 查询
     * 2.实现表链接
     * hasMany 有多个 belongsTo 一对一
     * */
    protected $hidden=['delete_time','update_time'];
    public static function getBannerByID($id){

        $banner = self::with(['items','items.images'])
                  ->find($id);


        return $banner;

    }


    public function items(){

        return $this ->hasMany('BannerItem','banner_id','id');
    }

    public function item1(){
    }
}

