<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:54
 */

namespace app\api\validate;


class IDCollection extends BaseValidate
{
    /*
     *
     * 遍历数组中元素
     *
     * */
    protected $rule = [
        'ids' => 'require|checkIDs'
    ];

    protected $message =[
        'ids' => 'ids参数必须是以逗号分隔的多个正整数'
    ];

    protected function checkIDs($value){
        /*
         * 把字符串打散成数组
         * 遍历数组ID元素，验证ID值
         * */
        $values = explode(',',$value);

        if(empty($values)){
            return false;
        }
        foreach ($values as $id){

            if(!$this -> isPositiveInteger($id)){
                return false;
            }
        }
        return true;
    }
}
