<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:28
 */

namespace app\api\model;


class Product extends BaseModel
{

    /*
     * 隐藏字段
     * pivot 是一个多对多表
     *
     *
     *
     * */
    protected $hidden = [
        'delete_time', 'main_img_id', 'pivot', 'from', 'category_id',
        'create_time', 'update_time'];

    public function getMainImgUrlAttr($value,$data){
        return $this->prefixImgUrl($value,$data);
    }


    public static function getMostRecent($count){
        /*
         * 限制数量
         * 倒序排列
         * */
        $product = self::limit($count)
                   ->order('create_time desc')
                   ->select();

        return $product;
    }

    public static function getProductsByCategoryID($categoryID){
        /*
         * 查询条件
         * */
        $products = self::where('category_id','=',$categoryID)
                    ->select();
        return $products;
    }

}