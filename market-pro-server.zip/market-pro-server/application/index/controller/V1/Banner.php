<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/13
 * Time: 12:41
 */

namespace app\index\controller\V1;
use app\index\validate\IDMustBePostiveInt;
use app\index\model\Banner as BannerModel;





class Banner
{
        public  function  getBanner($id){
            (new IDMustBePostiveInt())->goCheck();
            $banner = BannerModel::getBannerByID($id);
            return $banner;

            }

}





