<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/5/26
 * Time: 12:50
 */

namespace app\lib\enum;


class ScopeEnum
{
    const User = 16;

    const Super = 32;
}