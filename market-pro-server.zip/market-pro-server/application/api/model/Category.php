<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:27
 */

namespace app\api\model;


class Category extends BaseModel
{

    public function image(){
        return $this->belongsTo('image','topic_img_id','id');
    }
}