<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/10
 * Time: 15:51
 */

namespace app\sample\controller;

use app\index\model\Banner as BannerModel;
//Request实例接收数据get|post
use think\Request;
use think\Route;

class Test
{

    public function hello($id,$name){



        (new IDMustBePostiveInt())->goCheck();
        $banner = BannerModel:: getBannerByID($id);
        return $banner;



    }

    public function jack($id){
        echo "hello jack" ;
        $name=Request::instance()->param('name');
        echo $name;
        return $id;

    }

    public function jane(){

    $all = Request::instance()->param();            //param 所有参数  get 从路由url得到  route从路径上得到的get变量  post获得post变量

    var_dump($all);
    }

    public function micheal(){
        $all = input('param.');

        var_dump($all);
    }


    public function kangkang(Request $request){
        $all = $request -> param();
        var_dump($all);
    }

}





