<?php
    /**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/26
 * Time: 10:21
 */

    namespace app\api\controller\V1;

    use app\api\validate\TestValidate;
    use app\index\validate\IDMustBePostiveInt;
    use app\lib\exception\BannerMissException;
    use think\Exception;
    use think\Validate;
    use app\api\model\Banner as BannerModel;

    class Banner
    {
        public function getBannerTest()
        {
            $data = [
                'name' => 'vendor1111111111111',
                'email' => '2844329389qq.com'
            ];

            $validate = new Validate([
                'name' => 'require|max:10',
                'email' => 'email'
            ]);


            /*batch()方法校验所有参数*/ /*echo 输出对象 var_dump输出数组*/
            // $result = $validate->check($data);
            // echo $validate->getError();

            $result = $validate->batch()->check($data);
            var_dump($validate->getError());
        }

        public function getBannerT()
        {
            $data = [
                'name' => 'vendor1111111111111',
                'email' => '2844329389qq.com'
            ];

            $validate = new TestValidate();
            $result = $validate->batch()
                ->check($data);

            var_dump($validate->getError());

        }


        public function getBannerTo($id)
        {
            $data = [
                'id' => $id
            ];

            $validate = new IDMustBePostiveInt();
            $result = $validate->batch()->check($data);

            if ($result) {

            } else {

            }
        }

        public function getBannerExTest($id)
        {
            /*
             * 调用验证层
             * 调用业务层、异常
             *
             * */
            ((new IDMustBePostiveInt())->goCheck());

            try {
                $banner = BannerModel::getBannerByIDT($id);
            } catch (Exception $ex) {
                $err = [
                    'error_code' => 10001,
                    'msg' => $ex->getMessage()
                ];
                return json($err, 400);
            }
            return $banner;
        }


        public function getBannerTMV($id)
        {
            /*
             * 调用验证层
             * 模型 直接调用get方法（前提继承Model）返回的是对象  查询返回的是数组get,all(模型),find,select(DB)
             * 调用业务层、异常
             * 异常没有处理最后都会走进render方法里面
             * */
            ((new IDMustBePostiveInt())->goCheck());

//         查询   $banner = BannerModel::getBannerByID($id);

//         model  $banner = BannerModel::all($id);

            $banner = BannerModel::with(['items', 'items.images'])->find($id);

            if (!$banner) {
                throw new BannerMissException();
            }

            return json($banner);
        }


        public function getBannerTVersion($id,$version)
        {
            /*
             * 封装模型 模型返回的结果是一个对象
             * 版本迭代out类，还是通过路由与V2的使用
             * */
            if($version==1) {
                ((new IDMustBePostiveInt())->goCheck());

                $banner = BannerModel::getBannerByID($id);

                if (!$banner) {
                    throw new BannerMissException();
                }

                $c = config('setting.img_prefix');
                return $banner;
            }
            if($version==2) {
                ((new IDMustBePostiveInt())->goCheck());

                $banner = BannerModel::getBannerByID($id);

                if (!$banner) {
                    throw new BannerMissException();
                }

                $c = config('setting.img_prefix');
                return $banner;
            }
            if($version==3) {
                ((new IDMustBePostiveInt())->goCheck());

                $banner = BannerModel::getBannerByID($id);

                if (!$banner) {
                    throw new BannerMissException();
                }

                $c = config('setting.img_prefix');
                return $banner;
            }
        }



        public function getBanner($id)
        {
            /*
             * 封装模型 模型返回的结果是一个对象
             *
             * */
            ((new IDMustBePostiveInt())->goCheck());

            $banner = BannerModel::getBannerByID($id);

            if (!$banner) {
                throw new BannerMissException();
            }

            $c = config('setting.img_prefix');
            return $banner;
        }





    }


