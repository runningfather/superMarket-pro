<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/11/15
 * Time: 17:23
 */


echo "jjjj";