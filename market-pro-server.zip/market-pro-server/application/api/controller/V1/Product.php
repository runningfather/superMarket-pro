<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/29
 * Time: 15:39
 */

namespace app\api\controller\V1;


use app\api\validate\Count;
use app\api\model\Product as productModel;
use app\api\validate\IDMustBePostiveInt;
use app\lib\exception\ProductException;

class Product
{
    public function getRecent($count=15){
        /*
         * $result 是一个数组模型对象
         * 数据集 tp5提供的数据集对象->临时隐藏属性
         * 通过数据集对象完成对数组数据处理的方法
         * */
        ((new Count())->goCheck());
        $result = productModel::getMostRecent($count);

        if(!$result){
            throw new ProductException();
        }
        $collection = collection($result);
        $products = $collection->hidden(['summary']);

        return json($products);
    }


    public function getAllProductInCategory($id){
        (new IDMustBePostiveInt())->goCheck();
        $result = productModel::getProductsByCategoryID($id);
        if(!$result){
            throw new ProductException();
        }
        $collection = collection($result);
        $result = $collection -> hidden(['summary']);
        return json($result);
    }
}
