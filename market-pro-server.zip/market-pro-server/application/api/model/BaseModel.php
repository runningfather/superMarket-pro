<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 21:01
 */

namespace app\api\model;


use think\Model;

class BaseModel extends Model
{


    /*
     * 有getUrlAttr方法，有url会自动继承
     * 在这里面写，因为多种url不适合
     * 遂只写子方法 被子类调用
     * */
    protected function prefixImgUrl($value,$data){
        /*
         * 重写getUrlAttr
         * 图片地址设置 extra公开配置路径 public下配置文件
         * 判断是本地还是网络图片 $data中的from from==1说明是本地的
         * 实现图片拼接处理
         * */
        $finalUrl = $value;
        if($data['from'] == 1){
            $finalUrl = config('setting.img_prefix').$value;
        }

        return $finalUrl;
    }
}


