<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/28
 * Time: 16:35
 * extra 是tp5目录下默认的 配置路径 手动创建
 * image 需要放在 public下 只有public 可以允许外界访问
 */

    return [
        'img_prefix' => 'http://z.cn',
        'token_expire_in'=>7200
    ];