<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/6/3
 * Time: 16:17
 */

namespace app\api\model;


class User extends BaseModel
{
    /*
     * 简单的model
     * 复杂的service
     * */
    public static function getByOpenID($openid){
        $user = self::where('openid','=',$openid)
                ->find();
        return $user;
    }
}