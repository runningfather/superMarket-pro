<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/5/29
 * Time: 10:13
 */

namespace app\lib\exception;


use app\api\validate\BaseValidate;

class ThemeMissException extends BaseValidate
{
    public $code = 404;
    public $msg = '指定主题不存在，请检查主题ID';
    public $errorCode = 30000;
}

