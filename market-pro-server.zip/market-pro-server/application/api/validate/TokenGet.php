<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/6/3
 * Time: 16:12
 */

namespace app\api\validate;


class TokenGet extends BaseValidate
{
        protected $rule = [
            'code' => 'require|isNotEmpty'
        ];

        protected $message =[
            'code'=>'没有code无法申请token'
        ];

}