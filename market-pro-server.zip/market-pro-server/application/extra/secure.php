<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/6/3
 * Time: 18:56
 */

return [
    'token_salt' => '',
    'pay_back_url' => ''
//    http://2whczb.webx.cc
    //Ngrok
];