<?php
/**
 * Created by PhpStorm.
 * User: VULCAN
 * Date: 2018/6/3
 * Time: 16:19
 */

namespace app\api\service;


use app\api\validate\TokenGet;
use app\lib\exception\TokenException;
use think\Exception;
use app\lib\exception\weChatException;
use app\api\model\User as UserModel;

class UserToken extends Token
{
    /*
     * 少写了一个return哭死掉了一直出不来，ss级低级错误
     * 将token与数据保存缓存$wxResult $uid 16
     * 初始化参数
     * 构造方法，将extend\wx参数填入
     *
     * curl_get 向微信请求数据的方法 lib\common
     * */

    protected $code;
    protected $wxAppID;
    protected $wxAppSecret;
    protected $wxLoginUrl;

    function __construct($code)
    {
        $this->code = $code;
        $this->wxAppID = config('wx.app_id');
        $this->wxAppSecret = config('wx.app_secret');
        $this->wxLoginUrl = sprintf(
            config('wx.login_url'),
            $this->wxAppID, $this->wxAppSecret, $this->code);
    }


    public function get(){
       /*
        * 发送请求给微信
        * 获取请求结果  巩固:解码json_decode有true为数组，无true为对象 编码：返回值字符串使用json_encode
        * 调用成功，无errcode 微信成功或者失败返回都是200状态码
        * 调用异常
        * */
        $result = curl_get($this->wxLoginUrl);
        $wxResult = json_decode($result,true);

        if(empty($wxResult)){
            throw new Exception('获取session_key及openID时异常，微信内部错误11');
        }else{
            $loginFail =array_key_exists('errcode',$wxResult);
            if($loginFail){

                    $this ->processLoginError($wxResult);
            }else{

                   return $this->grantToken($wxResult);
            }
        }}


        private function grantToken($wxResult){
            /*
             * 拿到openid
             * 数据库里看一下，这个openid是不是已经存在
             * 如果存在则不处理，如果不存在那么新增一条user记录 把id号查出来，放进缓存
             * 生成令牌，准备缓存数据，写入缓存
             * 把令牌返回给客户端
             * key:令牌
             * value:wxResult,uid,scope(权限)
             * */

            $openid = $wxResult['openid'];
            $user = UserModel::getByOpenID($openid);
            if($user){
                $uid = $user->id;
            }
            else{
                $uid = $this->newUser($openid);
            }
            $cachedValue = $this->prepareCachedValue($wxResult,$uid);
            $token = $this->saveToCache($cachedValue);
            return $token;
        }

        private function saveToCache($cachedValue){
            /*
             * 生成key
             * 把数组转化成字符串json_encode 字符串也是json格式
             * 缓存时间
             * 保存缓存
             * cache 写入缓存tp5自带缓存
             * */
            $key = self::generateToken();
            $value = json_encode($cachedValue);
            $expire_in = config('setting.token_expire_in');

            $request =cache($key,$value,$expire_in);
            if(!$request){
                throw new TokenException([
                    'msg' => '服务器异常',
                    'errorCoe' => 10005
                ]);

            }
            return $key;
        }

        private function prepareCachedValue($wxResult,$uid){
        /*
         * numberCache
         * redis
         * 缓存value的封装
         * */
        $cachedValue = $wxResult;
        $cachedValue['uid'] = $uid;
        $cachedValue['scope'] =16;
        return $cachedValue;
        }

        private function newUser($openid){
        $user = UserModel::create([
            'openid' => $openid
        ]);
        return $user->id;
        }

        private function processLoginError($wxResult){
        throw new weChatException(
              [

                'msg'=>'code发送请求错误',
                  'errorCode'=>99999
              ]
            );
        }


}
