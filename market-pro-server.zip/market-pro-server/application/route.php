<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------



    use think\Route;


//    模块 控制器 操作方法名
    Route::any('jack/:id','sample/test/jack');

    Route::any('jane/:id','sample/test/jane');

    Route::any('micheal/:id','sample/test/micheal');

    Route::any('kangkang/:id','sample/test/kangkang');

    Route::any('bannerTest/:id','api/v1.Banner/getBannerTest');

    Route::any('bannerT/:id','api/v1.banner/getBannerT');

    Route::any('bannerTo/:id','api/v1.Banner/getBannerTo');

    Route::any('bannerExTest/:id','api/v1.banner/getBannerExTest');

    /*
     * 版 本 号- :version
     * */
    Route::any('api/:version/banner/:id','api/:version.Banner/getBanner');
    /*
     *config 路有完整匹配 route_complete_match
     **/
    Route::any('api/:version/Theme','api/:version.theme/getSimpleList');
    /*
     * 路由分组
     * */
    Route::any('api/:version/theme/:id','api/:version.theme/getComplexOne',[],['id'=>'\d+']);

    Route::any('api/:version/product/recent','api/:version.product/getRecent');

    Route::any('api/:version/category','api/:version.category/getAllCategories');

    Route::any('api/:version/product/getAllProductCategory','api/:version.product/getAllProductInCategory');

    Route::any('api/:version/token/user','api/:version.token/getToken');

    /*
     * 路由分组
    Route::group('api/:version',function (){
        Route::get('/theme','api/:version.theme/getSimpleList');
        Route::get('/theme/:id','api/:version.theme/getComplexOne');
    });

    */